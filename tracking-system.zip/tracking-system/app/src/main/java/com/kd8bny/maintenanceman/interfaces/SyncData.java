package com.kd8bny.maintenanceman.interfaces;

public interface SyncData {
        void onDownloadComplete(Boolean isComplete);

        void onDownloadStart();
}
